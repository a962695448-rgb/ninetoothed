"""Replay the deliberately injected fault from saved SSA and inputs."""

from pathlib import Path

import numpy as np

from ninetoothed.interpreter import interpret_program
from ninetoothed.interpreter.debugger import compare_programs, load_reproducer

directory = Path(__file__).parent
reference, inputs, options = load_reproducer(directory / "reference")
candidate, candidate_inputs, candidate_options = load_reproducer(directory / "candidate")
comparison = compare_programs(reference, candidate, inputs, **options)
assert not comparison.equal, "The saved candidate no longer reproduces the injected fault."
assert comparison.output_differences == ("out",)
assert comparison.first_operation is not None
assert comparison.first_operation.opcode == "arith.constant"
expected = inputs["x"] * 2 + 1
result = interpret_program(reference, inputs, **options)
np.testing.assert_allclose(result.outputs["out"], expected, rtol=1e-3, atol=1e-3)
candidate_result = interpret_program(candidate, candidate_inputs, **candidate_options)
np.testing.assert_allclose(
    candidate_result.outputs["out"],
    candidate_inputs["x"] * 3 + 1,
    rtol=1e-3,
    atol=1e-3,
)
print("Fault type: deliberately injected constant 2 -> 3; saved SSA comparison")
print("Correct reference output verified against NumPy")
print(f"Different outputs: {comparison.output_differences}")
print(f"First different operation: {comparison.first_operation}")
