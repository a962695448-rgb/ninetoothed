﻿ninetoothed.Tensor.subs
=======================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.subs