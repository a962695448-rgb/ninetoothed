﻿ninetoothed.make
================

.. currentmodule:: ninetoothed

.. autofunction:: make