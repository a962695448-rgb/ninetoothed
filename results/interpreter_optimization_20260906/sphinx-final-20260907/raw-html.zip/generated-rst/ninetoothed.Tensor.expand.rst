﻿ninetoothed.Tensor.expand
=========================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.expand