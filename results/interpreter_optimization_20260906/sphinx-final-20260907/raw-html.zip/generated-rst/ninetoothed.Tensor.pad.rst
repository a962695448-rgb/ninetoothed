﻿ninetoothed.Tensor.pad
======================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.pad