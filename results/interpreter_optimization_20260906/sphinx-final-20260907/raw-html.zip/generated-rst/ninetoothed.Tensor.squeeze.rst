﻿ninetoothed.Tensor.squeeze
==========================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.squeeze