﻿ninetoothed.jit
===============

.. currentmodule:: ninetoothed

.. autofunction:: jit