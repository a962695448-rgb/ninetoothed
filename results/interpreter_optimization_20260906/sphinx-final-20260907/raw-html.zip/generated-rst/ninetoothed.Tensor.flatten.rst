﻿ninetoothed.Tensor.flatten
==========================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.flatten