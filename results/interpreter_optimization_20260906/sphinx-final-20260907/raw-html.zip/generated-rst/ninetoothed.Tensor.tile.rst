﻿ninetoothed.Tensor.tile
=======================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.tile