﻿ninetoothed.Tensor.eval
=======================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.eval