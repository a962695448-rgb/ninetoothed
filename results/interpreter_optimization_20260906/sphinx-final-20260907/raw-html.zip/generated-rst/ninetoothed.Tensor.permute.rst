﻿ninetoothed.Tensor.permute
==========================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.permute