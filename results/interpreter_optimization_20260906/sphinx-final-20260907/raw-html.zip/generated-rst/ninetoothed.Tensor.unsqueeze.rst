﻿ninetoothed.Tensor.unsqueeze
============================

.. currentmodule:: ninetoothed

.. automethod:: Tensor.unsqueeze