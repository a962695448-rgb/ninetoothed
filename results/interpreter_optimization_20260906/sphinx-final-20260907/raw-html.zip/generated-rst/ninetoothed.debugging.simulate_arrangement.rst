﻿ninetoothed.debugging.simulate\_arrangement
===========================================

.. currentmodule:: ninetoothed.debugging

.. autofunction:: simulate_arrangement